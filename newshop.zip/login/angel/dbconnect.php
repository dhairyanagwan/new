<?php
$con = mysqli_connect( "localhost", "root", "root" );
mysqli_select_db( $con, "D_D" );
?>
