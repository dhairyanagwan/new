// need a previous sibiling selector
//http://stackoverflow.com/questions/1817792/css-previous-sibling-selector