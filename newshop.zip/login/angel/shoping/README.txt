A Pen created at CodePen.io. You can find this one at https://codepen.io/m7/pen/qrORGp.

 