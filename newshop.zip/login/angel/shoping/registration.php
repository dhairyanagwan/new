
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<!-- <!--  Latest compiled and minified CSS
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

jQuery library
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

Latest compiled JavaScript
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
 -->
<link href="css/bootstrap.css" rel="stylesheet" />
<link href="css/bootstrap-theme.css" rel="stylesheet" />
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<?php
require_once 'navigation.php';
?>
	<div align="center">
				<form action="shopingvalidate.php" method="post"
			style="height: 200px; width: 200px">
			<div class="form-group">
				<label for="name">Name</label> <input type="text"
					class="form-control" id= "name" name="name">
			</div>
			<div class="form-group">
				<label for="email">Email address:</label> <input type="email"
					class="form-control" id="email" name="email">
			</div>
			<div class="form-group">
				<label for="pwd">Password:</label> <input type="password"
					class="form-control" id="pwd" name="pass">
			</div>
			<div class="form-group">
				<label for="pws">comfirm password:</label> <input type="password"
					class="form-control" id="pws" name="pass1">
			</div>
			<div class="form-group">
				<label for="Mob">Mobile No.:</label> <input type="text"
					class="form-control" id="mob" name="mobile">
			</div>
			
			<button type="submit" class="btn btn-default">Submit</button>
		</form>
	</div>
</body>
</html>