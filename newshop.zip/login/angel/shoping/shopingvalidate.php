<?php
$name = $_REQUEST ['name'];
$email = $_REQUEST ['email'];
$pass = $_REQUEST ['pass'];
$cpass = $_REQUEST ['pass1'];
$mobile = $_REQUEST ['mobile'];

$con = mysqli_connect( "localhost", "root", "root" );
mysqli_select_db( $con, "D_D" );
if ($con) {
	
	if ("$pass" == "$cpass") {
		$query = "insert into user_info values('$name','$email','$pass','$mobile')";
		if (mysqli_query ( $con, $query )) {
			
			echo "REGISTRAION SUCCESSFULL";
		} else {
			echo "REGISTRAION UNSUCCESSFULL";
		}
	} else {
		echo "UNMATCHED PASSWORD AND CONFIRM PASSWORD";
	}
}

echo "<br><a href='registration.php'>BACK TO LOGIN PAGE</a>";
?>