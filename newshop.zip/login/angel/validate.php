<?php 

	$fname=$_REQUEST['lname'];
	$username=$_REQUEST['fname'];
	$pass=$_REQUEST['pass'];	
	$email=$_REQUEST['email'];
	$con=mysqli_connect("localhost:3306","root","root");
	mysqli_select_db($con,"D_D");
	if($con){
			$query="insert into user_info values('$fname','$username','$pass','$email')";
			if(mysqli_query($con, $query)){
				echo "REGISTRAION SUCCESSFULL";
				
			}
			else{
				echo "REGISTRAION SUCCESSFULL";
			}
	}
	else{
		echo "database is not selected";
	}
	echo "<br><a href='signup.php'>BACK TO LOGIN PAGE</a>";
?>