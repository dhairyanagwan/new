<head>
<title>SIGNUP PAGE</title>
</head>
<body>
<form action="validate.php" method="post">
<div>
<table>
<tr><td>ENTER THE FIRST NAME::<input type ="text" name="fname"></td></tr>
<tr><td>ENTER THE LAST NAME::<input type ="text" name="lname"></td></tr>
<tr><td>ENTER THE USERNAME::<input type ="text" name="username"></td></tr>
<tr><td>ENTER THE PASSWORD::<input type ="password" name="pass"></td></tr>
<tr><td>ENTER THE EMAIL::<input type ="email" name="email"></td></tr>
<tr><td><input type ="submit" name="submit" value="SUBMIT"></td></tr>
</table>
</div>
</form>
</body>