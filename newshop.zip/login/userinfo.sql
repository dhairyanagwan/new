create database D_D;
show databases;

use d_d;
create table user_info(
username varchar(20),
email varchar(50) primary key,
ppassword varchar(20), 
mobile int(10)
);

drop table user_info;
drop table login_info;

desc user_info;

select * from user_info;

create table login_info(
email varchar(50) primary key,
ppassword varchar(20),
date1 date);

delimiter //
create trigger user_login
after insert on
user_info for each row
begin

declare email varchar(20);
declare ppassword varchar(50);
     declare date1 date; 
     set email = new.email;
		set ppassword= new.ppassword;
        set date1=now();
INSERT INTO login_info value(new.email,new.ppassword,date1);
end;//
DELIMITER ;
drop trigger abc;

insert into user_info values('dhairya','nagwan95@gmail.com','1234','123');
select * from login_info; 